# Trap the Mouse (A:29) :mouse2:
## Description:
Se va crea o interfata grafica ce va oferi utilizatorului posibilitatea sa joace o partidă de
TrapTheMouse, atat cu calculatorul, cât și cu un alt opponent. Calculatorul va lua decizii bune
conform cu regulile jocului (trebuei sa exista macar 3 nivele de dificultate legate de cum joacă
calculatorul). Tabla de joc este generată de la început cu diverse obstacole.
https://www.mathplayground.com/logic_trap_the_mouse.html